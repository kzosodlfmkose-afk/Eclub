
package com.example.eclubhelper

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val eclubPackage = "py.com.eclub.eclub2"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvSource = findViewById<TextView>(R.id.tvSource)
        val tvCI = findViewById<TextView>(R.id.tvCI)
        val tvPW = findViewById<TextView>(R.id.tvPW)
        val btnCopyCI = findViewById<Button>(R.id.btnCopyCI)
        val btnCopyPW = findViewById<Button>(R.id.btnCopyPW)
        val btnOpenApp = findViewById<Button>(R.id.btnOpenApp)

        // Read clipboard
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clipText = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
        tvSource.text = clipText.ifBlank { "Portapapeles vacío" }

        val (ci, pw) = parsePair(clipText)
        tvCI.text = ci
        tvPW.text = pw

        btnCopyCI.setOnClickListener {
            copy(ci, "CI copiado")
        }
        btnCopyPW.setOnClickListener {
            copy(pw, "Contraseña copiada")
        }
        btnOpenApp.setOnClickListener {
            openEclub()
        }
    }

    private fun copy(text: String, toast: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("text", text))
        Toast.makeText(this, toast, Toast.LENGTH_SHORT).show()
    }

    private fun openEclub() {
        val launch = packageManager.getLaunchIntentForPackage(eclubPackage)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
        } else {
            // Open Play Store fallback
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$eclubPackage")))
            } catch (e: Exception) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$eclubPackage")))
            }
        }
    }

    private fun parsePair(src: String): Pair<String,String> {
        if (src.isBlank()) return "" to ""
        // Accepted formats: "CI<TAB>Pass", "CI,Pass", "CI\nPass", "CI Pass"
        val s = src.trim()
        val separators = listOf("\t", ",", "\n", " ")
        for (sep in separators) {
            val parts = s.split(Regex(sep)).map { it.trim() }.filter { it.isNotEmpty() }
            if (parts.size >= 2) return parts[0] to parts[1]
        }
        // If only one token and looks like CI (digits), assign to CI
        val digits = s.filter { it.isDigit() }
        return if (digits.length in 5..12) digits to "" else "" to ""
    }

        val btnCopyPair = findViewById<Button>(R.id.btnCopyPair)
        btnCopyPair.setOnClickListener {
            val ci = findViewById<TextView>(R.id.tvCI).text.toString()
            val pw = findViewById<TextView>(R.id.tvPW).text.toString()
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("pair", ci + "\n" + pw))
            Toast.makeText(this, "Copiado CI↵Pass", Toast.LENGTH_SHORT).show()
        }
}

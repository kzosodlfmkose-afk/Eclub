# eCLUB Helper

App Android que detecta CI y Pass desde el portapapeles.

- Copiar CI
- Copiar Pass
- Copiar CI↵Pass
- Abrir eCLUB

Compilación automática con GitHub Actions incluida.
